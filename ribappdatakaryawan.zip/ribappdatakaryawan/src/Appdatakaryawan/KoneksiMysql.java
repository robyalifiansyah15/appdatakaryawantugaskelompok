// File: KoneksiMysql.java
package Appdatakaryawan;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class KoneksiMysql {
    private static Connection mysqlconfig;

    public static Connection configDB() throws SQLException {
        try {
            String url = "jdbc:mysql://localhost:3306/db_karyawan"; // URL ke DB MySQL
            String user = "root"; // user default
            String pass = ""; // password default
            
            // Mendaftarkan driver dan membuat koneksi
            DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
            mysqlconfig = DriverManager.getConnection(url, user, pass);
            
        } catch (SQLException e) {
            // Tampilkan pesan error jika koneksi gagal
            JOptionPane.showMessageDialog(null, "Koneksi ke database MySQL gagal!\nPastikan XAMPP sudah berjalan.\nError: " + e.getMessage());
        }
        return mysqlconfig;
    }
}